ALPINE Base Image Builder
==============================

build from [MINI ROOT FILESYSTEM](https://alpinelinux.org/downloads/)

